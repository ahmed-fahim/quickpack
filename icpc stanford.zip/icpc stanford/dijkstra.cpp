vector<int> adjlist[N];
int dist[N];

void dijkstra(int s) {
  bool vis[N];
  memset(vis, false, sizeof vis);
  fill(dist, dist + N,INF);
  priority_queue< ii, vector<ii>, greater<ii> > q;
  dist[s] = 0;
  q.push( ii(0, s) );
  while(!q.empty()) {
    ii front = q.top(); q.pop();  
    int u = front.second, d = front.first;
    if(vis[u]) continue;
    vis[u] = true;
    for(ii wv : Adjlist[u]) { 
      if(dist[wv.second] > dist[u] + wv.first) {  // relax operation
        dist[wv.second] = dist[u] + wv.first;   
        q.push(ii(dist[wv.second], wv.second));
      }
    }
  }
  return;
}
