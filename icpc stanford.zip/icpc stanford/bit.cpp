/*
   In this BIT, $a[1...n]$ is the frequency array
   BIT[idx] stores for $a[idx - 2^r + 1]$ $\dots$ $a[idx]$
   r is the lowest bit of idx that is 1;
   $2^r$ = idx & -idx
*/
//returns a[idx] + a[idx-1] + ... + a[1].
int read(int idx){
  int sum = 0;
  while (idx > 0){
    sum += BIT[idx];
    idx -= (idx & -idx);
  }
  return sum;
}

void update(int idx ,int val){
  while (idx <= n){
    BIT[idx] += val;
    idx += (idx & -idx);
  }
}
