int M[LIM]; 	// M[i] contains the index of the smallest element of A[] at which a non-decreasing sequence of
// length i ends, A[M[1]], A[M[2]], ... form a nondecreasing subsequence as if there is a subsequence of length i ending at
// A[M[i]] then there exists a subsequence of length i-1 ending at P[M[i]] 
int P[LIM];		// P[i] contains the index of the parent of A[i] in the lis
int N;
int lis(int A[]) {
  M[0] = -1;
  memset(P, -1, sizeof P);
  M[1] = 0;
  int maxL = 1;		// maxL is the current length of the longest subsequence found, L is the length of subsequence
  // found ending at A[i]
  int low, high, mid;
  for(int i = 1; i < N; i++) {
    // for A[i], find the largest j such that A[M[j]] <= A[i]
    low = 0; high = maxL;
    while(high - low > 1) {
      mid = (low + high) >> 1;
      if(A[M[mid]] <= A[i]) low = mid;
      else high = mid;
    }
    if(A[M[high]] <= A[i]) mid = high;
    else mid = low;
    P[i] = M[mid];
    if(mid == maxL) M[++maxL] = i;
    else if(A[i] < A[M[mid + 1]]) M[mid+1] = i;
  }
  return maxL;
}
void printlis(int idx, const int A[]) {
  if(P[idx] >= 0) printlis(P[idx], A);
  cout << A[idx] << " ";
}
int main() {
  int A[LIM];
  cin >> N;
  for(int i = 0; i < N; i++) cin >> A[i];
  int ans = lis(A);
  printlis(M[ans], A); 
  return 0;
}
