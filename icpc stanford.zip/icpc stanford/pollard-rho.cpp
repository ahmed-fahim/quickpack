/* pollard rho integer factorisation */
LL pollard_rho(LL n) {
	LL y;
	LL x=rand()%n;
	y = x;
	LL d=1;	
	while(d==1 || d == n) {	
		x=(x*x+1)%n;
		y=((y*y+1) * (y*y+1) + 1)%n;
		d = gcd(n,(LL)abs(x - y));
	}
	return d;
}

void all_factor(LL n)
{
	LL d;
	while(n>1) {
		d = pollard_rho(n);
		printf("%lld\n",d);
		n = n/d;
	}
	return;
}