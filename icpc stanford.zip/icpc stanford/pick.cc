// points are (xa, ya), (xb, yb), (xc, yc), (xd, yd)
// ans = i + b, the number of points in the interior as well as the boundary of the quadrilateral
cin >> xa >> ya >> xb >> yb;
cin >> xc >> yc >> xd >> yd;
int b = 0;
b = gcd(abs(xa-xb), abs(ya-yb)) + gcd(abs(xb-xc),abs(yb-yc)) + gcd(abs(xc-xd),abs(yc-yd))  + gcd(abs(xd-xa),abs(yd-ya));
int A2 = 0;
x1 = xc - xa;
y1 = yc - ya;
x2 = xd - xb;
y2 = yd - yb;
A2 = abs(x1*y2 - x2*y1);
ans = (A2 + 2 + b)/2;
