int etf[N];
void etf_fill( int *etf) {
  etf[1] = 1;
  for(int i=2; i<=N; i++) {
    etf[i] = i; 
  }	
  for(int i=2; i<=N; i++) {
    if(etf[i] == i) {	// i is prime
      etf[i] = i-1;	// correcting its value
      for(int j=2; j*i <= N; j++) { //multiply (i-1) / i to all its multiples
        etf[j*i] = ( etf[j*i] / i) * (i - 1); 
      }
    }
  }
  for(int i=2; i<=N; i++) {
    if(etf[i] == i) {	//prime
      etf[i] = i-1;	//correcting for primes > sqrt(N)
    }
  }
}
/*Directly computing, taken from topcoder*/
int fi(int n)  { 
  int result = n; 
  int i; 
  for( i=2;i*i <= n;i++) { 
    if (n % i == 0) result -= result / i; 
    while (n % i == 0) n /= i; 
  } 
  if (n > 1) result -= result / n; 
  return result; 
} 
