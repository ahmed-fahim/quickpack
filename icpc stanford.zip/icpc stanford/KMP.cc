// KMP for string searching
#include <bits/stdc++.h>
using namespace std;

const int LIM = 10005;
int lookup[LIM];		// lookup is one indexed wrt the string target
// lookup[i] stores the largest j < i st target[1..j] is a 
// suffix of target[1...i]
string target;
void compute_table() {
  lookup[0] = -1;
  lookup[1] = 0;
  int pref = 0;	
  for(int i = 2; i <= target.size(); i++) { 
    while(pref != -1 && target[pref] != target[i - 1]) {
      pref = lookup[pref];
    }
    pref++;
    lookup[i] = pref;
  }
}

string str;
int main() {
  int pref;			// pref simply stores the largest prefix length metched till str[i]
  while(cin >> str >> target) {
    compute_table();
    pref = 0;
    for(int i = 0; i < str.size(); i++) {
      while(pref != -1 && str[i] != target[pref]) {
        pref = lookup[pref];
      }
      pref++;
      if(pref == target.size()) {
        printf("match found starting at index %d\n", i + 1 - (int)target.size());
        pref = lookup[pref];
      }
    }
  }
  return 0;
}
