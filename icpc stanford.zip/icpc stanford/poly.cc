#define ctype int
typedef vector<ctype> poly;
poly d(const poly& f) {
	poly df;
	for(int i=1; i < f.size(); i++) {
		df.push_back(f[i] * i);
	}
	//df.push_back(0);	
	return df;
}
poly operator+ (const poly &f, const poly &g) {
	poly h;
	int i=0;
	for(; i < min(f.size(), g.size()); i++) h.push_back(f[i] + g[i]);
	for(; i < f.size(); i++) h.push_back(f[i]);
	for(; i < g.size(); i++) h.push_back(g[i]);
	return h;
}
poly operator- (const poly &f, const poly &g) {
	poly h;
	int i=0;
	for(; i < min(f.size(), g.size()); i++) h.push_back(f[i] - g[i]);
	for(; i < f.size(); i++) h.push_back(f[i]);
	for(; i < g.size(); i++) h.push_back(-g[i]);
	return h;
}
poly operator* (const poly &f, const poly &g) {
	poly h(f.size() + g.size() - 1, 0);
	for(int i=0; i < f.size(); i++) {
		for(int j=0; j < g.size(); j++) {
			h[i+j] += f[i] * g[j];
		}
	}
	return h;
}
ostream &operator<< (ostream &os, const poly &f) {		// for direct output
	if(!f.size()) os << "0";
	else {
		os << f[0];
		for(int i=1; i < f.size(); i++) {
			os << " + " << f[i] << "x^" << i;
		}
	}
}

