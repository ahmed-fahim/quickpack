struct trie {
  trie *child[10];
  bool isLeaf;
  trie() { 
    memset(child, 0, sizeof child);
    isLeaf = false;
  }
  bool insert(const string& s) {
    int p;
    trie* tr = this;
    for(int i = 0; i < s.size(); i++) {
      p = s[i] - '0';
      if(tr->child[p] == NULL) tr->child[p] = new trie();
      tr = tr->child[p];
    }
    tr->isLeaf = true;
  }
};
